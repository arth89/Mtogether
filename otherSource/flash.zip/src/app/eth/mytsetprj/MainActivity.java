package app.eth.mytsetprj;

import java.io.IOException;

import android.app.Activity;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

@SuppressWarnings("deprecation")
public class MainActivity extends Activity implements Callback {

	private Camera camera;
	Parameters parameters;
	SurfaceHolder mHolder;
	boolean flag;

	Runnable myThread = new Runnable() {
		@Override
		public void run() {
			while (flag) {
				parameters.setFlashMode(Parameters.FLASH_MODE_TORCH);
				camera.setParameters(parameters);
				camera.startPreview();

				try {
					Thread.sleep(300, 0);
				} catch (InterruptedException e) {
				}

				parameters.setFlashMode(Parameters.FLASH_MODE_OFF);
				camera.setParameters(parameters);
				camera.stopPreview();
			}
		}
	};

	@Override
	protected void onStop() {
		super.onStop();
		if (camera != null) {
			camera.release();
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		SurfaceView preview = (SurfaceView) findViewById(R.id.PREVIEW);
		mHolder = preview.getHolder();
		mHolder.addCallback(this);

		camera = Camera.open();
		parameters = camera.getParameters();

		Button buttonStart = (Button) findViewById(R.id.buttonStart);
		Button buttonStop = (Button) findViewById(R.id.buttonStop);

		buttonStart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				flag = true;
				new Thread(myThread).start();
			}
		});

		buttonStop.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				flag = false;
				parameters.setFlashMode(Parameters.FLASH_MODE_OFF);
				camera.setParameters(parameters);
				camera.stopPreview();
			}
		});
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,int height) {
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		try {
			camera.setPreviewDisplay(holder);
		} catch (IOException e) {
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		camera.stopPreview();
		mHolder = null;
	}
}